import React from 'react';
import './SideDrawer.css';
import { DiAndroid, DiApple } from 'react-icons/di';
import { NavLink, Link } from 'react-router-dom';
import SignInPopup from '../Sign/Sign';
import Home from '../Home/Home';


const SideDrawer = props => {

    let drawerClasses = 'side-drawer'

    if (props.show) {
        drawerClasses = 'side-drawer open'
    }
    return (

        <nav className={drawerClasses}>
            <div className='UserID'>
                Hi Guest User
                <li className='cancel' onClick={props.click} >&#x2715;</li>
            </div>
            <div className='Login'>
                <div className='sign-button'>
                    <li  >
                        <a >SIGN IN</a>
                    </li>
                </div>
                <div className='sign-button'>
                    <li >
                        <a style={{borderRadius:10, }}>SIGN UP</a>
                    </li>
                </div>

            </div>
            <hr className='hr'></hr>
            <ul>
                <li> <NavLink exact to="/Home" activeClassName="active">
                    HOME
                </NavLink></li> <hr className='hr' />
                <li> <NavLink exact to="/TvShows" activeClassName="active">
                    TV SHOWS
                </NavLink></li> <hr className='hr' />
                <li> <NavLink exact to="/Movies" activeClassName="active">
                    MOVIES
                </NavLink></li> <hr className='hr' />
                <li> <NavLink exact to="/LiveTv" activeClassName="active">
                    LIVE TV
                </NavLink></li> <hr className='hr' />
                <li> <NavLink exact to="/News" activeClassName="active">
                    NEWS
                </NavLink></li> <hr className='hr' />
                <li> <NavLink exact to="/Food" activeClassName="active">
                    FOOD
                </NavLink></li> <hr className='hr' />
                <li> <NavLink exact to="/Health" activeClassName="active">
                    HEALTH
                </NavLink></li>
            </ul>
            <div className='Download'>
                DOWNLOAD APP
                <li><a href='/'><DiApple /></a></li>
                <li><a href='/'><DiAndroid /> </a></li>

            </div>
        </nav>


    )
}

export default SideDrawer