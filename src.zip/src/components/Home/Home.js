import React, { useEffect, useState, useRef } from "react";
import "./Home.css";
import { NavLink, Link } from "react-router-dom";

export default function Home() {

  const [index, setIndex] = useState(0);
  const [zoomLevel, setZoomLevel] = useState(1);

  const handleZoom = () => {
    setZoomLevel(zoomLevel + 0.02);
  };
  const Images = [
    "https://www.w3schools.com/css/img_5terre.jpg",
    "https://www.w3schools.com/css/img_forest.jpg",
    "https://www.w3schools.com/css/img_lights.jpg",
    "https://www.w3schools.com/css/img_5terre.jpg",
    "https://www.w3schools.com/css/img_forest.jpg",
    "https://www.w3schools.com/css/img_lights.jpg",
    "https://www.w3schools.com/css/img_5terre.jpg",
    "https://www.w3schools.com/css/img_forest.jpg",
    "https://www.w3schools.com/css/img_lights.jpg"
  ];

  useEffect(() => {
    // setInterval(onNext, 2000);
    setTimeout(handleTimeout, 5000);
  }, []);

  const onNext = () => {
    console.log(Images.length);

    if (index < Images.length - 1) {
      let i = index + 1;
      setIndex(i);
    } else {
      setIndex(0);
    }
  };

  const onPrev = () => {
    if (index > 0 && index < Images.length) {
      let i = index - 1;
      setIndex(i);
    } else {
      setIndex(Images.length - 1);
    }
  };

  const onJump = (i) => {
    setIndex(i);
  };

  const handleMouseMove = (event) => {
    const direction = event.clientX > window.innerWidth / 2 ? 'right' : 'left';
    if (direction === 'left') {
      setIndex((index - 1 + Images.length) % Images.length);
    } else if (direction === 'right') {
      setIndex((index + 1) % Images.length);
    }
  };

  const handleTimeout = () => {
    if (index === Images.length - 1) {
      setIndex(0);
    } else {
      setIndex(index + 1);
    }
  };
  const onNextTvShows = () => {
    console.log(Images.length);

    if (index < Images.length - 1) {
      let i = index + 1;
      setIndex(i);
    } else {
      setIndex(0);
    }
  };

  const onPreTvShows = () => {
    if (index > 0 && index < Images.length) {
      let i = index - 1;
      setIndex(i);
    } else {
      setIndex(Images.length - 1);
    }
  };

  const handleScroll = (event) => {
    const scrollLeft = event.target.scrollLeft;
    setIndex(scrollLeft / Images[0].width);
  };

  return (
    <div className="div">
      <div className="carousel"
        //  onMouseMove={handleMouseMove}
        onChange={useEffect}>
        {Images.map((item, i) =>
          i === index ? (
            <div className="carousel-item" key={i}>
              <img src={item} alt={item} draggable='true' className="carousel-item" />
            </div>

          ) : ""
        )}
        <div className="Prev-Next">
          <a className="prev" onClick={onPrev}>
            &#x3c;
          </a>
          <a className="next" onClick={onNext}>
            &#x3e;
          </a>
        </div>
      </div>
      <a className="carousel-dots">
        {Images.map((item, i) => (
          <text
            class="dot"
            className={`dot ${i === index ? "active" : ""}`}
            key={i}
            onClick={() => onJump(i)}
          > </text>
        ))}
      </a>
      <div className="Win">
        <div className="Item">
          <text className="TextWin">
            WIN Exclusives
          </text>
          <a href="#" className="More">+More</a>
        </div>
        <div className="WinItem">
          <img src="https://www.w3schools.com/css/img_forest.jpg" className="WinImages" />
          <img src="https://www.w3schools.com/css/img_forest.jpg" className="WinImages" />

        </div>
      </div>

      {/* Before TV Shows */}
      <div className="BeforeTv">
        <div className="Before">
          <text className="TextBefore">
            Before TV
          </text>
          <a href="#" className="More">+More</a>
        </div>
        <div className="BeforeItem">
          <div className="BeforeImg">
            <img src="https://www.w3schools.com/css/img_forest.jpg" className="" />
            <h6 className="BeforeTV_Span">
              <span>S21 | Epi 24 </span>
              <span>|</span>
              <span>8 hours ago</span>
            </h6>
          </div>
          <div className="BeforeImg">
            <img src="https://www.w3schools.com/css/img_forest.jpg" />
            <h6 className="BeforeTV_Span">
              <span>S21 | Epi 24 </span>
              <span>|</span>
              <span>8 hours ago</span>
            </h6>
          </div>
          <div className="BeforeImg">
            <img src="https://www.w3schools.com/css/img_forest.jpg" />
            <h6 className="BeforeTV_Span">
              <span>S21 | Epi 24 </span>
              <span>|</span>
              <span>8 hours ago</span>
            </h6>
          </div>
          <div className="BeforeImg">
            <img src="https://www.w3schools.com/css/img_forest.jpg" />
            <h6 className="BeforeTV_Span">
              <span>S21 | Epi 24 </span>
              <span>|</span>
              <span>8 hours ago</span>
            </h6>
          </div>
          <div className="BeforeImg">
            <img src="https://www.w3schools.com/css/img_forest.jpg" />
            <h6 className="BeforeTV_Span">
              <span>S21 | Epi 24 </span>
              <span>|</span>
              <span>8 hours ago</span>
            </h6>
          </div>
          <div className="BeforeImg">
            <img src="https://www.w3schools.com/css/img_forest.jpg" />
            <h6 className="BeforeTV_Span">
              <span>S21 | Epi 24 </span>
              <span>|</span>
              <span>8 hours ago</span>
            </h6>
          </div>
          <div className="BeforeImg">
            <img src="https://www.w3schools.com/css/img_forest.jpg" />
            <h6 className="BeforeTV_Span">
              <span>S21 | Epi 24 </span>
              <span>|</span>
              <span>8 hours ago</span>
            </h6>
          </div>
          <div className="BeforeImg">
            <img src="https://www.w3schools.com/css/img_forest.jpg" />
            <h6 className="BeforeTV_Span">
              <span>S21 | Epi 24 </span>
              <span>|</span>
              <span>8 hours ago</span>
            </h6>
          </div>
          <div className="BeforeImg">
            <img src="https://www.w3schools.com/css/img_forest.jpg" />
            <h6 className="BeforeTV_Span">
              <span>S21 | Epi 24 </span>
              <span>|</span>
              <span>8 hours ago</span>
            </h6>
          </div>
          <div className="BeforeImg">
            <img src="https://www.w3schools.com/css/img_forest.jpg" />
            <h6 className="BeforeTV_Span">
              <span>S21 | Epi 24 </span>
              <span>|</span>
              <span>8 hours ago</span>
            </h6>
          </div>
        </div>
      </div>

      {/* Live Tv Shows */}
      <div className="LiveTv">
        <div className="Live">
          <text className="TextLive">
            Live TV
          </text>

        </div>
        <div className="LiveItem">
          <img src="https://www.w3schools.com/css/img_forest.jpg" className="LiveImage" />
          <img src="https://www.w3schools.com/css/img_forest.jpg" className="LiveImage" />
          <img src="https://www.w3schools.com/css/img_forest.jpg" className="LiveImage" />
          <img src="https://www.w3schools.com/css/img_forest.jpg" className="LiveImage" />
          <img src="https://www.w3schools.com/css/img_forest.jpg" className="LiveImage" />
          <img src="https://www.w3schools.com/css/img_forest.jpg" className="LiveImage" />
          <img src="https://www.w3schools.com/css/img_forest.jpg" className="LiveImage" />

        </div>
      </div>

      {/* Tv Shows  */}
      <div className="TvShow">
        <div className="Shows">
          <text className="TextShows">
            TV Show
          </text>
          <a href="#" className="More">+More</a>
        </div>

        <div className="TVShows"
          //  onMouseMove={handleMouseMove}
          onChange={useEffect}>
          {Images.map((item, i) =>
            i === index ? (
              <div className="TVShows-item " key={i}>
                <img src={item} alt={item} draggable='true' className="TVShows-item " />
              </div>

            ) : ""
          )}
          <div className="Prev-Next">
            <a className="prev" onClick={onPreTvShows}>
              &#x3c;
            </a>
            <a className="next" onClick={onNextTvShows}>
              &#x3e;
            </a>
          </div>
        </div>
      </div>

      {/* Trending  Shows  */}
      <div className="Trending">
        <div className="TrendingTv">
          <text className="TextTrending">
            Trending
          </text>
          <a href="#" className="More">+More</a>
        </div>
        <div className="TrendingItem">
          <img src="https://www.w3schools.com/css/img_forest.jpg" className="TrandingImage" />
          <img src="https://www.w3schools.com/css/img_forest.jpg" className="TrandingImage" />
          <img src="https://www.w3schools.com/css/img_forest.jpg" className="TrandingImage" />
          <img src="https://www.w3schools.com/css/img_forest.jpg" className="TrandingImage" />
          <img src="https://www.w3schools.com/css/img_forest.jpg" className="TrandingImage" />
          <img src="https://www.w3schools.com/css/img_forest.jpg" className="TrandingImage" />
          <img src="https://www.w3schools.com/css/img_forest.jpg" className="TrandingImage" />
        </div>
      </div>

      {/* Recommended For You */}
      <div className="Recommended">
        <div className="Recommended_You">
          <text className="Text_Recommended">
            Recommended For You
          </text>
          <a href="#" className="More">+More</a>
        </div>
        <div className="Recommended_Item">
          <div className="Recommended_Image">
            <img src="https://www.w3schools.com/css/img_forest.jpg" />
            <h6 className="h6">
              <span>Asalu</span>
              <span>|</span>
              <span>13 Apr 2023</span>
            </h6>
          </div>
          <div className="Recommended_Image">
            <img src="https://www.w3schools.com/css/img_forest.jpg" />
            <h6 className="h6">
              <span>Asalu</span>
              <span>|</span>
              <span>13 Apr 2023</span>
            </h6>
          </div>
          <div className="Recommended_Image">
            <img src="https://www.w3schools.com/css/img_forest.jpg" />
            <h6 className="h6">
              <span>Asalu</span>
              <span>|</span>
              <span>13 Apr 2023</span>
            </h6>
          </div>
          <div className="Recommended_Image">
            <img src="https://www.w3schools.com/css/img_forest.jpg" />
            <h6 className="h6">
              <span>Asalu</span>
              <span>|</span>
              <span>13 Apr 2023</span>
            </h6>
          </div>
          <div className="Recommended_Image">
            <img src="https://www.w3schools.com/css/img_forest.jpg" />
            <h6 className="h6">
              <span>Asalu</span>
              <span>|</span>
              <span>13 Apr 2023</span>
            </h6>
          </div>
          <div className="Recommended_Image">
            <img src="https://www.w3schools.com/css/img_forest.jpg" />
            <h6 className="h6">
              <span>Asalu</span>
              <span>|</span>
              <span>13 Apr 2023</span>
            </h6>
          </div>
          <div className="Recommended_Image">
            <img src="https://www.w3schools.com/css/img_forest.jpg" />
            <h6 className="h6">
              <span>Asalu</span>
              <span>|</span>
              <span>13 Apr 2023</span>
            </h6>
          </div>
          <div className="Recommended_Image">
            <img src="https://www.w3schools.com/css/img_forest.jpg" />
            <h6 className="h6">
              <span>Asalu</span>
              <span>|</span>
              <span>13 Apr 2023</span>
            </h6>
          </div>
          <div className="Recommended_Image">
            <img src="https://www.w3schools.com/css/img_forest.jpg" />
            <h6 className="h6">
              <span>Asalu</span>
              <span>|</span>
              <span>13 Apr 2023</span>
            </h6>
          </div>
          <div className="Recommended_Image">
            <img src="https://www.w3schools.com/css/img_forest.jpg" />
            <h6 className="h6">
              <span>Asalu</span>
              <span>|</span>
              <span>13 Apr 2023</span>
            </h6>
          </div>
        </div>
      </div>
      {/* Top Movies  Shows  */}
      <div className="Top_Movies">
        <div className="Top_MoviesTv">
          <text className="TextTop_Movies">
            Top Movies
          </text>
          <a href="#" className="More">+More</a>
        </div>
        <div className="Top_Movies_Item">
          <img src="https://www.w3schools.com/css/img_forest.jpg" className="Top_Movies_Image" />
          <img src="https://www.w3schools.com/css/img_forest.jpg" className="Top_Movies_Image" />
          <img src="https://www.w3schools.com/css/img_forest.jpg" className="Top_Movies_Image" />
          <img src="https://www.w3schools.com/css/img_forest.jpg" className="Top_Movies_Image" />
          <img src="https://www.w3schools.com/css/img_forest.jpg" className="Top_Movies_Image" />
          <img src="https://www.w3schools.com/css/img_forest.jpg" className="Top_Movies_Image" />
          <img src="https://www.w3schools.com/css/img_forest.jpg" className="Top_Movies_Image" />
          <img src="https://www.w3schools.com/css/img_forest.jpg" className="Top_Movies_Image" />
          <img src="https://www.w3schools.com/css/img_forest.jpg" className="Top_Movies_Image" />
          <img src="https://www.w3schools.com/css/img_forest.jpg" className="Top_Movies_Image" />
          <img src="https://www.w3schools.com/css/img_forest.jpg" className="Top_Movies_Image" />
          <img src="https://www.w3schools.com/css/img_forest.jpg" className="Top_Movies_Image" />
          <img src="https://www.w3schools.com/css/img_forest.jpg" className="Top_Movies_Image" />
        </div>
      </div>
      {/* Family Shows  */}
      <div className="Family">
        <div className="FamilyShow">
          <text className="Text_Family">
            Family
          </text>
          <a href="/" className="More">+More </a>
        </div>
        <div className="Family_Item">
          <img src="https://www.w3schools.com/css/img_5terre.jpg" className="Family_Image" />
          <img src="https://www.w3schools.com/css/img_5terre.jpg" className="Family_Image" />
          <img src="https://www.w3schools.com/css/img_5terre.jpg" className="Family_Image" />
          <img src="https://www.w3schools.com/css/img_5terre.jpg" className="Family_Image" />
          <img src="https://www.w3schools.com/css/img_5terre.jpg" className="Family_Image" />
          <img src="https://www.w3schools.com/css/img_5terre.jpg" className="Family_Image" />

        </div>
      </div>
      {/* Comedy Shows */}
      <div className="Comedy">
        <div className="Comedy_Shows">
          <text className="Text_Comedy">
            Comedy
          </text>
          <a href="/" className="More">+More</a>
        </div>
        <div className="Comedy_Item">
          <img src="https://www.w3schools.com/css/img_5terre.jpg" className="Comedy_Image" />
          <img src="https://www.w3schools.com/css/img_5terre.jpg" className="Comedy_Image" />
          <img src="https://www.w3schools.com/css/img_5terre.jpg" className="Comedy_Image" />
          <img src="https://www.w3schools.com/css/img_5terre.jpg" className="Comedy_Image" />
          <img src="https://www.w3schools.com/css/img_5terre.jpg" className="Comedy_Image" />
          <img src="https://www.w3schools.com/css/img_5terre.jpg" className="Comedy_Image" />
          <img src="https://www.w3schools.com/css/img_5terre.jpg" className="Comedy_Image" />
        </div>
      </div>
      {/* Romance Shows */}
      <div className="Romance">
        <div className="Romance_Shows">
          <text className="Text_Romance">
            Romance
          </text>
          <a href="/" className="More">+More</a>
        </div>
        <div className="Romance_Item">
          <img src="https://www.w3schools.com/css/img_5terre.jpg" className="Romance_Image" />
          <img src="https://www.w3schools.com/css/img_5terre.jpg" className="Romance_Image" />
          <img src="https://www.w3schools.com/css/img_5terre.jpg" className="Romance_Image" />
          <img src="https://www.w3schools.com/css/img_5terre.jpg" className="Romance_Image" />
          <img src="https://www.w3schools.com/css/img_5terre.jpg" className="Romance_Image" />
          <img src="https://www.w3schools.com/css/img_5terre.jpg" className="Romance_Image" />
          <img src="https://www.w3schools.com/css/img_5terre.jpg" className="Romance_Image" />
          <img src="https://www.w3schools.com/css/img_5terre.jpg" className="Romance_Image" />
          <img src="https://www.w3schools.com/css/img_5terre.jpg" className="Romance_Image" />
          <img src="https://www.w3schools.com/css/img_5terre.jpg" className="Romance_Image" />
          <img src="https://www.w3schools.com/css/img_5terre.jpg" className="Romance_Image" />
          <img src="https://www.w3schools.com/css/img_5terre.jpg" className="Romance_Image" />
        </div>
      </div>
      {/* Classic Shows */}
      <div className="Classic">
        <div className="Classic_Shows">
          <text className="Classic_Text">
            Classic
          </text>
          <a href="/" className="More">+More</a>
        </div>
        <div className="Classic_Item">
          <img src="https://www.w3schools.com/css/img_5terre.jpg" className="Classic_Image" />
          <img src="https://www.w3schools.com/css/img_5terre.jpg" className="Classic_Image" />
          <img src="https://www.w3schools.com/css/img_5terre.jpg" className="Classic_Image" />
          <img src="https://www.w3schools.com/css/img_5terre.jpg" className="Classic_Image" />
          <img src="https://www.w3schools.com/css/img_5terre.jpg" className="Classic_Image" />
          <img src="https://www.w3schools.com/css/img_5terre.jpg" className="Classic_Image" />
          <img src="https://www.w3schools.com/css/img_5terre.jpg" className="Classic_Image" />
          <img src="https://www.w3schools.com/css/img_5terre.jpg" className="Classic_Image" />
          <img src="https://www.w3schools.com/css/img_5terre.jpg" className="Classic_Image" />
          <img src="https://www.w3schools.com/css/img_5terre.jpg" className="Classic_Image" />
          <img src="https://www.w3schools.com/css/img_5terre.jpg" className="Classic_Image" />
          <img src="https://www.w3schools.com/css/img_5terre.jpg" className="Classic_Image" />
        </div>
      </div>
      {/* Folklore Shows */}
      <div className="Folklore">
        <div className="Folklore_Shows">
          <text className="Folklore_text">
            Folklore
          </text>
          <a href="/" className="More">+More</a>
        </div>
        <div className="Folklore_Item">
          <img src="https://www.w3schools.com/css/img_5terre.jpg" className="Folklore_Image" />
          <img src="https://www.w3schools.com/css/img_5terre.jpg" className="Folklore_Image" />
          <img src="https://www.w3schools.com/css/img_5terre.jpg" className="Folklore_Image" />
          <img src="https://www.w3schools.com/css/img_5terre.jpg" className="Folklore_Image" />
          <img src="https://www.w3schools.com/css/img_5terre.jpg" className="Folklore_Image" />
          <img src="https://www.w3schools.com/css/img_5terre.jpg" className="Folklore_Image" />
          <img src="https://www.w3schools.com/css/img_5terre.jpg" className="Folklore_Image" />
          <img src="https://www.w3schools.com/css/img_5terre.jpg" className="Folklore_Image" />
          <img src="https://www.w3schools.com/css/img_5terre.jpg" className="Folklore_Image" />
          <img src="https://www.w3schools.com/css/img_5terre.jpg" className="Folklore_Image" />
          <img src="https://www.w3schools.com/css/img_5terre.jpg" className="Folklore_Image" />
          <img src="https://www.w3schools.com/css/img_5terre.jpg" className="Folklore_Image" />
        </div>
      </div>
      {/* Action / Thriller show */}
      <div className="Action">
        <div className="Action_Shows">
          <text className="Action_text">
            Action / Thriller
          </text>
          <a href="/" className="More">+More</a>
        </div>
        <div className="Action_Item">
          <img src="https://www.w3schools.com/css/img_5terre.jpg" className="Action_Image" />
          <img src="https://www.w3schools.com/css/img_5terre.jpg" className="Action_Image" />
          <img src="https://www.w3schools.com/css/img_5terre.jpg" className="Action_Image" />
          <img src="https://www.w3schools.com/css/img_5terre.jpg" className="Action_Image" />
          <img src="https://www.w3schools.com/css/img_5terre.jpg" className="Action_Image" />
          <img src="https://www.w3schools.com/css/img_5terre.jpg" className="Action_Image" />
          <img src="https://www.w3schools.com/css/img_5terre.jpg" className="Action_Image" />
          <img src="https://www.w3schools.com/css/img_5terre.jpg" className="Action_Image" />
          <img src="https://www.w3schools.com/css/img_5terre.jpg" className="Action_Image" />
          <img src="https://www.w3schools.com/css/img_5terre.jpg" className="Action_Image" />
          <img src="https://www.w3schools.com/css/img_5terre.jpg" className="Action_Image" />
          <img src="https://www.w3schools.com/css/img_5terre.jpg" className="Action_Image" />
        </div>
      </div>
      {/* Latest News */}
      <div className="Latest">
        <div className="Latest_show">
          <text className="Latest_Text">
            Latest News
          </text>
          <a href="/" className="More">+More</a>
        </div>
        <div className="Latest_Item">
          <div className="Latest_Image">
            <img src="https://www.w3schools.com/css/img_forest.jpg" className="" />
            <h6 className="Latst">
              <span>7 AM ETV News | 30 May 23</span>
              <span>|</span>
              <span>13 Apr 2023</span>
            </h6>
          </div>
        </div>
      </div>
      {/* Food  */}
      <div className="Food">
        <div className="Food_Show">
          <text className="Food_Text">
            Food
          </text>
          <a href="/" className="More">+More</a>
        </div>
        <div className="Food_Item">
          <img src="https://www.w3schools.com/css/img_forest.jpg" className="Food_Image" />
          <img src="https://www.w3schools.com/css/img_forest.jpg" className="Food_Image" />
          <img src="https://www.w3schools.com/css/img_forest.jpg" className="Food_Image" />
          <img src="https://www.w3schools.com/css/img_forest.jpg" className="Food_Image" />
          <img src="https://www.w3schools.com/css/img_forest.jpg" className="Food_Image" />
          <img src="https://www.w3schools.com/css/img_forest.jpg" className="Food_Image" />
          <img src="https://www.w3schools.com/css/img_forest.jpg" className="Food_Image" />
          <img src="https://www.w3schools.com/css/img_forest.jpg" className="Food_Image" />
          <img src="https://www.w3schools.com/css/img_forest.jpg" className="Food_Image" />
          <img src="https://www.w3schools.com/css/img_forest.jpg" className="Food_Image" />
          <img src="https://www.w3schools.com/css/img_forest.jpg" className="Food_Image" />
          <img src="https://www.w3schools.com/css/img_forest.jpg" className="Food_Image" />
          <img src="https://www.w3schools.com/css/img_forest.jpg" className="Food_Image" />
          <img src="https://www.w3schools.com/css/img_forest.jpg" className="Food_Image" />
          <img src="https://www.w3schools.com/css/img_forest.jpg" className="Food_Image" />
          <img src="https://www.w3schools.com/css/img_forest.jpg" className="Food_Image" />
          <img src="https://www.w3schools.com/css/img_forest.jpg" className="Food_Image" />
          <img src="https://www.w3schools.com/css/img_forest.jpg" className="Food_Image" />
          <img src="https://www.w3schools.com/css/img_forest.jpg" className="Food_Image" />
          <img src="https://www.w3schools.com/css/img_forest.jpg" className="Food_Image" />

          <img src="https://www.w3schools.com/css/img_forest.jpg" className="Food_Image" />
        </div>
      </div>
            {/* Health & Fitness  */}
            <div className="Health">
        <div className="Health_Show">
          <text className="Health_Text">
          Health & Fitness
            </text>
          <a href="/" className="More">+More</a>
        </div>
        <div className="Health_Item">
          <img src="https://www.w3schools.com/css/img_forest.jpg" className="Health_Image" />
          <img src="https://www.w3schools.com/css/img_forest.jpg" className="Health_Image" />
          <img src="https://www.w3schools.com/css/img_forest.jpg" className="Health_Image" />
          <img src="https://www.w3schools.com/css/img_forest.jpg" className="Health_Image" />
          <img src="https://www.w3schools.com/css/img_forest.jpg" className="Health_Image" />
          <img src="https://www.w3schools.com/css/img_forest.jpg" className="Health_Image" />
          <img src="https://www.w3schools.com/css/img_forest.jpg" className="Health_Image" />
          <img src="https://www.w3schools.com/css/img_forest.jpg" className="Health_Image" />
          <img src="https://www.w3schools.com/css/img_forest.jpg" className="Health_Image" />
          <img src="https://www.w3schools.com/css/img_forest.jpg" className="Health_Image" />
          <img src="https://www.w3schools.com/css/img_forest.jpg" className="Health_Image" />
          <img src="https://www.w3schools.com/css/img_forest.jpg" className="Health_Image" />
          <img src="https://www.w3schools.com/css/img_forest.jpg" className="Health_Image" />
          <img src="https://www.w3schools.com/css/img_forest.jpg" className="Health_Image" />
          <img src="https://www.w3schools.com/css/img_forest.jpg" className="Health_Image" />
          <img src="https://www.w3schools.com/css/img_forest.jpg" className="Health_Image" />
          <img src="https://www.w3schools.com/css/img_forest.jpg" className="Health_Image" />
          <img src="https://www.w3schools.com/css/img_forest.jpg" className="Health_Image" />
          <img src="https://www.w3schools.com/css/img_forest.jpg" className="Health_Image" />
          <img src="https://www.w3schools.com/css/img_forest.jpg" className="Health_Image" />

          <img src="https://www.w3schools.com/css/img_forest.jpg" className="Health_Image" />
        </div>
      </div>
    </div>

  );
}

