import React, { useState } from 'react'
import './NavBar.css';
import logo from '/Users/WIN/Desktop/webwin/src/image/et.jpg';
import subscribe from '/Users/WIN/Desktop/webwin/src/image/subscribe.png';
import profile from '/Users/WIN/Desktop/webwin/src/image/profile-icon-white.png';
import { CiSearch } from 'react-icons/ci';

import google from '/Users/WIN/Desktop/webwin/src/image/google.png';
import facebook from '/Users/WIN/Desktop/webwin/src/image/facebook-new.png';
import { Button, Input } from "@mui/material";
import { Link, NavLink } from 'react-router-dom';
import Home from '../Home/Home';
import { DiAndroid, DiApple } from 'react-icons/di';
import { HiMenuAlt1 } from 'react-icons/hi';

// Drawer_Botton Left
const DrawerToggleButton = (props) => {
    const [Drawers, setDraweRs] = useState(false);

    const HandleDrawer = () => {
        setDraweRs({ SideDrawer })
    }

    return (
        <button className='toggle-button' onClick={HandleDrawer}>
            {/* <div className='toggle-button__line' />
           <div className='toggle-button__line' />
            <div className='toggle-button__line' /> */}
            <HiMenuAlt1 color='#fff' size={'100%'} />
        </button>
    )
}

// SideDrawer 
const SideDrawer = props => {

    let drawerClasses = 'side-drawer'

    if (props.show) {
        drawerClasses = 'side-drawer open'
    }
    return (

        <nav className={drawerClasses}>
            <div className='UserID'>
                Hi Guest User
                <li className='cancel' onClick={props.click} >&#x2715;</li>
            </div>
            <div className='Login'>
                <div className='sign-button'>
                    <li  >
                        <a >SIGN IN</a>
                    </li>
                </div>
                <div className='sign-button'>
                    <li >
                        <a style={{ borderRadius: 10, }}>SIGN UP</a>
                    </li>
                </div>

            </div>
            <hr className='hr'></hr>
            <ul>
                <li> <NavLink exact to="/Home" activeClassName="active">
                    HOME
                </NavLink></li> <hr className='hr' />
                <li> <NavLink exact to="/TvShows" activeClassName="active">
                    TV SHOWS
                </NavLink></li> <hr className='hr' />
                <li> <NavLink exact to="/Movies" activeClassName="active">
                    MOVIES
                </NavLink></li> <hr className='hr' />
                <li> <NavLink exact to="/LiveTv" activeClassName="active">
                    LIVE TV
                </NavLink></li> <hr className='hr' />
                <li> <NavLink exact to="/News" activeClassName="active">
                    NEWS
                </NavLink></li> <hr className='hr' />
                <li> <NavLink exact to="/Food" activeClassName="active">
                    FOOD
                </NavLink></li> <hr className='hr' />
                <li> <NavLink exact to="/Health" activeClassName="active">
                    HEALTH
                </NavLink></li>
            </ul>
            <div className='Download'>
                DOWNLOAD APP
                <li><a href='/'><DiApple /></a></li>
                <li><a href='/'><DiAndroid /> </a></li>

            </div>
        </nav>


    )
}

const SignInPopup = ({ onClose }) => {
    const [username, setUsername] = useState('');
    const [password, setPassword] = useState('');

    const handleSubmit = (e) => {
        e.preventDefault();

    };

    return (
        <div className="popup-container">
            <div className="popup-content">

                <text className='h4'>SIGN IN </text>
                <text className="close-button" onClick={onClose}>
                    &#10005;
                </text>
                <form onSubmit={handleSubmit}>
                    <Input
                        style={{ color: "white" }}
                        label="Error"
                        placeholder="Email/Mobile *"
                        value={username}
                        onChange={(e) => setUsername(e.target.value)}
                        required={true}
                    />

                    <Input
                        style={{ color: "white" }}
                        type="password"
                        placeholder="Password *"
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                        required={true}
                    />
                    <a className="forgot">FORGOT PASSWORD ?</a>
                    <div className="Sign_In">
                        <Button type="submit" >
                            SIGN IN
                        </Button>
                    </div>
                    <div class="divider">
                        OR
                    </div>
                    <div className='socialmedia'>
                        <a className='facebooksign' href='#'><img size={30} src={facebook} color='#fff' className='facebooksign' /></a>
                        <img className='googlesign' href='#' src={google} />
                    </div>
                    <div className="Sign_up">
                        <Button style={{ color: '#ddd', backgroundColor: '#8149bf', borderRadius: 20, marginTop: 20, cursor: 'pointer' }}>
                            SIGN UP</Button>
                    </div>
                </form>

            </div>


        </div>
    );
};


const Toolbar = props => {
    const [showPopup, setShowPopup] = useState(false);
    const [Drawer, setDraweR] = useState(false);

    const HandleDrawer = () => {
        setDraweR({ SideDrawer })
    }

    const handlePopupOpen = () => {
        setShowPopup(true)
    }
    return (
        <header className='toolbar'>
            <nav className='toolbar__navigation'>
                <div className='toolbar__navigation-button'>
                    <DrawerToggleButton onClick={Drawer && <SideDrawer />} />
                </div>
                <div className='toolbar__logo'>
                    <NavLink exact to='/Home' activeClassName='active'>
                        <img src={logo} /></NavLink>
                </div>
                {/* <div className='spacer'/> */}
                <div className='tool_navigation-items'>
                    <ul>
                        <li> <NavLink exact to="/Home" activeClassName='inactive'>
                            HOME
                        </NavLink></li>
                        <li> <NavLink exact to="/TvShows" activeClassName="active">
                            TV SHOWS
                        </NavLink></li>
                        <li> <NavLink exact to="/Movies" activeClassName="active">
                            MOVIES
                        </NavLink></li>
                        <li> <NavLink exact to="/LiveTv" activeClassName="active">
                            LIVE TV
                        </NavLink></li>
                        <li> <NavLink exact to="/News" activeClassName="active">
                            NEWS
                        </NavLink></li>
                        <li> <NavLink exact to="/Food" activeClassName="active">
                            FOOD
                        </NavLink></li>
                        <li> <NavLink exact to="/Health" activeClassName="active">
                            HEALTH
                        </NavLink></li>
                    </ul>
                </div>
                <div className='tool_navigation-Right'>
                    <img src={subscribe} className='subscribe' />
                    <li> <CiSearch size={30} className='img__Search' /></li>

                    <div className='dropdown'>
                        <img src={profile} className='profile' />
                        <div className='dropdown-content'>
                            <li href='/' onClick={handlePopupOpen}>
                                {showPopup && <SignInPopup onClose={() => setShowPopup(false)} />}
                                SIGN IN</li>
                            <br />

                            <li href='/'>SIGN UP</li>
                        </div>
                    </div>
                </div>
            </nav>
        </header>
    )
}

export default Toolbar