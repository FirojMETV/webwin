import { useRef, useState } from "react";
import play from '/Users/WIN/Desktop/webwin/src/image/play.png';
import pause from '/Users/WIN/Desktop/webwin/src/image/pause.png';
import backward from '/Users/WIN/Desktop/webwin/src/image/backward.png';
import forward from '/Users/WIN/Desktop/webwin/src/image/forward.png';
import setting from '/Users/WIN/Desktop/webwin/src/image/setting.png';
import full from '/Users/WIN/Desktop/webwin/src/image/fullscreen.png';
import exit from '/Users/WIN/Desktop/webwin/src/image/maximize.png';
import sound from '/Users/WIN/Desktop/webwin/src/image/icons8-sound-48.png';
import mute from '/Users/WIN/Desktop/webwin/src/image/icons8-mute-50.png';

import "./More.css";

function Player() {

    const videoRef = useRef(null);
    const [playing, setPlaying] = useState(false);
    const [currentTime, setCurrentTime] = useState(0);
    const [videoTime, setVideoTime] = useState(0);
    const [progress, setProgress] = useState(0);
    const [fullScreen, setFullScreen] = useState(false)
    const [isMuted, setIsMuted] = useState(false);

    const videoHandler = (control) => {
        if (control === "play") {
            videoRef.current.play();
            setPlaying(true);
            var vid = document.getElementById("video1");
            setVideoTime(vid.duration);
        } else if (control === "pause") {
            videoRef.current.pause();
            setPlaying(false);
        }
    };
    const handleMuted = () => {
        setIsMuted(!isMuted)
        videoRef.current.muted = !isMuted
    }
    const handleProgress = () => {
        setCurrentTime(videoRef.current.currentTime);
    }
    const fastForward = () => {
        videoRef.current.currentTime += 10;
    };

    const backwards = () => {
        videoRef.current.currentTime -= 10;
    };
    const toggleFullscreen = () => {
        if (videoRef.current.requestFullscreen) {
            videoRef.current.requestFullscreen();
        } else if (videoRef.current.mozRequestFullScreen) {
            videoRef.current.mozRequestFullScreen();
        } else if (videoRef.current.webkitRequestFullscreen) {
            videoRef.current.webkitRequestFullscreen();
        } else if (videoRef.current.msRequestFullscreen) {
            videoRef.current.msRequestFullscreen();
        }
    };
    window.setInterval(function () {
        setCurrentTime(videoRef.current?.currentTime);
        setProgress((videoRef.current?.currentTime / videoTime) * 100);
    }, 1000);

    return (
        <div className="Video">
            <video
                id="video1"
                ref={videoRef}
                className="video"
                
                onTimeUpdate={handleProgress}
            >
                <source src="http://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4" type="video/mp4" className="" />
            </video>

            <div className="controlsContainer">
                <div className="controls">
                    <img
                        onClick={backwards}
                        className="controlsIcon"
                        alt=""
                        src={backward}
                    />
                    {playing ? (
                        <img
                            onClick={() => videoHandler("pause")}
                            className="controlsIcon--small"
                            alt=""
                            src={pause}
                        />
                    ) : (
                        <img
                            onClick={() => videoHandler("play")}
                            className="controlsIcon--small"
                            alt=""
                            src={play}
                        />
                    )}
                    <img
                        className="controlsIcon"
                        onClick={fastForward}
                        alt=""
                        src={forward}
                    />
                </div>
            </div>

            <div className="timecontrols">
                {playing ? (
                    <img
                        onClick={() => videoHandler("pause")}
                        className="controlsIcon--Play-pause "
                        alt=""
                        src={pause}
                    />
                ) : (
                    <img
                        onClick={() => videoHandler("play")}
                        className="controlsIcon--Play-pause "
                        alt=""
                        src={play}
                    />
                )}
                <div className="time_progressbarContainer">
                    <div
                        onTimeUpdate={handleProgress}
                        style={{ width: `${progress}%` }}
                        className="time_progressBar"
                    >
                        <span className="progress-bar-value"
                         style={{ width: `${currentTime / videoTime * 100}%` }} />
                    </div>
                </div>
                <p className="controlsTime">
                    {Math.floor(currentTime / 60) +
                        ":" +
                        ("0" + Math.floor(currentTime % 60)).slice(-2)}
                    <text> / </text>
                    {Math.floor(videoTime / 60) +
                        ":" +
                        ("0" + Math.floor(videoTime % 60)).slice(-2)}
                </p>
                <img
                    src={setting}
                    className="controlsIcon--Play-pause " />

                {fullScreen ? (<img
                    src={full}
                    className="controlsIcon--Play-pause "
                    onClick={toggleFullscreen} />)
                    :
                    (<img
                        className="controlsIcon--Play-pause "
                        onClick={toggleFullscreen}
                        src={exit} />
                    )
                }
                {isMuted ? (<img
                    src={mute}
                    className="controlsIcon--Play-pause "
                    onClick={handleMuted} />)
                    :
                    (<img
                        className="controlsIcon--Play-pause "
                        onClick={handleMuted}
                        src={sound} />)}
            </div>
        </div>
    );
}

export default Player;

