import React from 'react'
import playstore from "/Users/WIN/Desktop/webwin/src/image/playstore.png";
import apple from "/Users/WIN/Desktop/webwin/src/image/apple.png";
import { BsFacebook, BsInstagram, BsTwitter } from 'react-icons/bs'
import './Footer.css'

const Footer = () => {
    return (
        <>
            <div className='Footer'>
                <div className='Connect'>
                    <div className='download'>
                        <ul className='leftItem'>
                            <li>
                                <text className='text'>Download App</text>
                            </li>
                            <li>
                                <img src={playstore} className='playstore' />
                            </li>
                            <li>
                                <img src={apple} className='apple' />
                            </li>
                        </ul>
                    </div>
                    <div className='Follow'>
                        <ul className='RightItem'>
                            <text className='Contact'>Connect with us</text>
                            <a className='facebook' >
                                <BsFacebook href='' />
                            </a>
                            <a className='insta' >
                                <BsInstagram color='#fff' />
                            </a>
                            <a className='twitt'>
                                <BsTwitter />
                            </a>
                        </ul>
                    </div>
                </div>
                <div className='aboutus'>
                    <ul className='aboutText'>
                        <li role='button'><a > ABOUT US</a> </li>
                       <li> <a>|</a></li>
                        <li><a> CONTACT US </a></li>
                        <li> <a>|</a></li>
                        <li><a>PRIVACY POLICY </a> </li>
                        <li> <a>|</a></li>
                        <li><a>TERMS & CONDITIONS</a>  </li>
                        <a>|</a>
                        <li><a> FAQ </a></li>
                        <li> <a>|</a></li>
                        <li> <a>FEEDBACK </a></li>
                        <li> <a>|</a></li>
                        <li><a>  SUBSCRIPTIONS</a> </li>
                    </ul>
                </div>
                <div className='copyright'>
                    <text>
                        © Eenadu Television Pvt. Ltd. 2023. All Rights Reserved
                    </text>
                </div>
            </div>
        </>
    )
}

export default Footer


