import React, { useState } from 'react'
import './TvShows.css';

import google from '/Users/WIN/Desktop/webwin/src/image/google.png';
import facebook from '/Users/WIN/Desktop/webwin/src/image/facebook-new.png';
import { Button, Input } from "@mui/material";
import { Link, NavLink } from 'react-router-dom';


const SignInPopup = ({ onClose,props }) => {
    const [username, setUsername] = useState('');
    const [password, setPassword] = useState('');

    const handleSubmit = (e) => {
        e.preventDefault();

    };

    return (
        <div className="popup-container">
            <div className="popup-content">

                <text className='h4'>SIGN IN </text>
                <text className="close-button" onClick={onClose}>
                    &#10005;
                </text>
                <form onSubmit={handleSubmit}>
                    <Input
                        style={{ color: "white" }}
                        label="Error"
                        placeholder="Email/Mobile *"
                        value={username}
                        onChange={(e) => setUsername(e.target.value)}
                        required={true}
                    />

                    <Input
                        style={{ color: "white" }}
                        type="password"
                        placeholder="Password *"
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                        required={true}
                    />
                    <a className="forgot">FORGOT PASSWORD ?</a>
                    <div className="Sign_In">
                        <Button type="submit" >
                            SIGN IN
                        </Button>
                    </div>
                    <div class="divider">
                        OR
                    </div>
                    <div className='socialmedia'>
                        <a className='facebooksign' href='#'><img size={30} src={facebook} color='#fff' className='facebooksign' /></a>
                        <img className='googlesign' href='#' src={google} />
                    </div>
                    <div className="Sign_up">
                        <Button style={{ color: '#ddd', backgroundColor: '#8149bf', borderRadius: 20, marginTop: 20, cursor: 'pointer' }}>
                            SIGN UP</Button>
                    </div>
                </form>

            </div>


        </div>
    );
};
