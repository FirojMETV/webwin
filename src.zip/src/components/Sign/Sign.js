import React, { useState } from 'react'
import './Sign.css';

import { CiSearch } from 'react-icons/ci';
import DrawerToggleButton from '../SideDrawer/DrawerToggleButton';
import google from '/Users/WIN/Desktop/webwin/src/image/google.png';
import facebook from '/Users/WIN/Desktop/webwin/src/image/facebook-new.png';
import { Button, Input } from "@mui/material";

const SignInPopup = ({ onClose }) => {
    const [username, setUsername] = useState('');
    const [password, setPassword] = useState('');

    const handleSubmit = (e) => {
        e.preventDefault();

    };

    return (
        <div className="popup-container">
            <div className="popup-content">

                <div className='h4'>SIGN IN </div>
                <br/>
                <hr className='hr'/>
                <text className="close-button" onClick={onClose}>
                    &#10005;
                </text>
                <form onSubmit={handleSubmit}>
                    <Input
                        style={{ color: "white" }}
                        label="Error"
                        placeholder="Email/Mobile *"
                        value={username}
                        onChange={(e) => setUsername(e.target.value)}
                        required={true}
                    />
                    <br/>
                    <hr className='hr'/>
                    <Input
                        style={{ color: "white" }}
                        type="password"
                        placeholder="Password *"
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                        required={true}
                        helperText='Password Error'
                    />
                    <br/>
                    <hr className='hr'/>
                    <a className="forgot">FORGOT PASSWORD ?</a>
                    <div className="Sign_In">
                        <Button type="submit" >
                            SIGN IN
                        </Button>
                    </div>
                    <div class="divider">
                        OR
                    </div>
                    <div className='socialmedia'>
                       <img  src={facebook} className='facebooksign' />
                        <img className='googlesign' href='#' src={google} />
                    </div><br/>
                    <div className="Sign_up">
                    <br/>
                        <Button style={{ color: '#ddd', backgroundColor: '#8149bf', borderRadius: 20, marginTop: 10, cursor: 'pointer' }}>
                            SIGN UP</Button>
                    </div>
                </form>

            </div>


        </div>
    );
};
export default SignInPopup;
