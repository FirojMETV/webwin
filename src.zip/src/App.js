import React, { Component } from 'react'
import { BrowserRouter, Route, Routes } from 'react-router-dom'
import BackDrop from './components/Backdrop/BackDrop';
import SignInPopup from './components/Sign/Sign';
import './App.css'
import Home from './components/Home/Home';
import Footer from './components/Footer/Footer';
import NavBar from './components/NavBar/NavBar';
import Player from './components/More/More';
class App extends Component {

  render() {
    return (
      <BrowserRouter forceRefresh={true}  >
         <NavBar />
        <Routes>
          <Route path='Home'
            element={<Home />} />
          <Route path='TvShows'
            element={< SignInPopup />} />
             <Route path='Movies'
            element={<Player/>} />
        </Routes>
        <Footer />
      </BrowserRouter>

    )
  }
}
export default App